// Copyright 1998-2016 Epic Games, Inc. All Rights Reserved.

#ifndef __PROTOTYPE1_H__
#define __PROTOTYPE1_H__

#include "EngineMinimal.h"

DECLARE_LOG_CATEGORY_EXTERN(LogPrototype1, Log, All);


#endif
