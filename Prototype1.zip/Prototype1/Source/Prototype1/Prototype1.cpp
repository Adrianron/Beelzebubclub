// Copyright 1998-2016 Epic Games, Inc. All Rights Reserved.

#include "Prototype1.h"


IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Prototype1, "Prototype1" );

DEFINE_LOG_CATEGORY(LogPrototype1)
 